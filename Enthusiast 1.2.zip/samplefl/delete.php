<?php
require_once('header.php');
?>

    <h1>Delete Yourself</h1>

<?php
include 'config.php';
include ENTH_PATH . 'show_delete.php';

require_once('footer.php');
