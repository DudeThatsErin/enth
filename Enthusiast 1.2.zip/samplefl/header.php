<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> Sample Fanlisting </title>
</head>

<body>

<div style="text-align: center; margin: auto; font-weight: bold;">
<a href="index.php">Index</a> &bull;
<a href="list.php">List</a> &bull;
<a href="join.php">Join</a> &bull;
<a href="update.php">Update</a> &bull;
<a href="delete.php">Delete</a> &bull;
<a href="lostpass.php">Lost Password</a> &bull;
<a href="affiliates.php">Affiliates</a>
</div>
