<?php
require_once('header.php');
?>

    <h1>Update your Information</h1>

<?php
include 'config.php';
include ENTH_PATH . 'show_update.php';

require_once('footer.php');