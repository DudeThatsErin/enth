<?php
require_once('header.php');
?>

    <h1>Join the Fanlisting</h1>

<?php
include 'config.php';
include ENTH_PATH . 'show_join.php';

require_once('footer.php');