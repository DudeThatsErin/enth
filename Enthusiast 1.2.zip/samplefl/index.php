<?php
require_once('header.php');
?>

    <h1>Welcome</h1>

    <p>This is a sample fanlisting. :)</p>

<?php
include 'config.php';
include ENTH_PATH . 'show_stats.php';

require_once('footer.php');