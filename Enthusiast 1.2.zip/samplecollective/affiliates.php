<?php
include "header.php"; ?><b>Affiliates:</b><br><br><?php
include ENTH_PATH . 'show_collective_affiliates.php';