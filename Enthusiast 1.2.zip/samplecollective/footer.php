<?php if (basename($_SERVER['SCRIPT_FILENAME']) == 'footer.php') die();
?>

</body>
</html>