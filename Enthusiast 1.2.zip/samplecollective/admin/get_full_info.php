<?php

require 'config.php';

require_once('mod_settings.php');

//$infocoll = get_listing_info( $listing );
